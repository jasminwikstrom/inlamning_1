CREATE PROCEDURE addtocart(IN kundId BIGINT, IN bestallningsId BIGINT, IN produktId BIGINT)
  begin 
  declare answer text default 'error';
  declare foundProduct bigint(20);
  
  declare exit handler for sqlexception
  begin
    rollback;
    select 'Det gick fel, rullar tillbaka';
  end;
  
  select produkt.id into foundProduct from produkt
  where produkt.id = produktId;
  
  if foundProduct is not null then set answer = 'found!';
    begin        
        
        ## sök vidare
        declare foundKund bigint(20) default null;
        declare foundDelBestallning bigint(20) default null;
        declare foundBestallning bigint(20) default null;
		declare antalAvProdukt bigint(20) default 0;
        
		select produkt.lagerantal into antalAvProdukt from produkt
        where produkt.id = foundProduct;
        
        if antalAvProdukt < 1 then
		  signal sqlstate '45000';
        end if;
        
        select kund.id into foundKund from kund
        where kund.id = kundId;
        
        if foundKund is null then
          signal sqlstate '45000';
        end if;
        
        set autocommit = 0;
		START TRANSACTION;
       
        select delbestallning.id into foundDelBestallning from delbestallning
        inner join bestallning on bestallning.id = delbestallning.bestallningsid
	    inner join produkt on delbestallning.produktid = produkt.id
        inner join kund on bestallning.kundid = kund.id
        where bestallning.id = bestallningsId and produkt.id = produktId and kund.id = kundId
        limit 1;
        
        select bestallning.id into foundBestallning from bestallning
        join kund on kund.id = bestallning.kundid
        where bestallning.id = bestallningsId and kund.id = kundId;
       
        if foundDelBestallning is null and foundBestallning is null then
          begin
          
			insert into bestallning (kundid, bestallningsdatum, betalningssatt) values
			  (kundId, now(), "VISA");
          
            set foundBestallning = last_insert_id();
          
            insert into delbestallning (produktid, bestallningsid, antalx) values
		      (produktId, foundBestallning, 1);
              
			update produkt set lagerantal = lagerantal - 1
            where produkt.id = foundProduct and lagerantal > 0;
              
			set answer = 'created bestallning and delbestallning';
		  end;
		elseif foundDelBestallning is not null and foundBestallning is not null then
		  begin
          
		   select produkt.lagerantal into antalAvProdukt from produkt
            where produkt.id = foundProduct;

				update delbestallning set antalx = antalx + 1
				where delbestallning.id = foundDelBestallning;
					
				update produkt set lagerantal = lagerantal - 1
				where produkt.id = foundProduct and lagerantal > 0;
				
				set answer = 'increased count';
		  end;
		elseif foundDelBestallning is null and foundBestallning is not null then
		  begin  
          
			select produkt.lagerantal into antalAvProdukt from produkt
            where produkt.id = foundProduct;
				insert into delbestallning (produktid, bestallningsid, antalx) values         
					(foundProduct, foundBestallning, 1);
					
				update produkt set lagerantal = lagerantal - 1
				where produkt.id = foundProduct;
		  
				set answer = 'created delbestallning';
			   end;
        end if;
	
	end;
    
    commit;
    set autocommit = 1;
  end if;	
  
  select answer;
end;

