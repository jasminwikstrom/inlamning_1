CREATE TRIGGER test
  AFTER UPDATE
  ON produkt
  FOR EACH ROW
  begin
	
	declare foundproduct bigint(20) default null;
	
	select slutilager.id into foundproduct from slutilager
	where slutilager.id = new.id;
	
	if new.lagerantal < 1 and foundproduct is null then
		insert into slutilager (produktid) values (new.id);
	end if;
end;

